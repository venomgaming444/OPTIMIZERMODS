package com.example.fastplace;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Client entrypoint. Gives the mod a real "loaded" log line, so you can check
 * latest.log for "[ObsidianCrystalOptimizer] loaded" if it ever seems inactive.
 * ClientModInitializer ships with Fabric Loader, so Fabric API is not needed.
 */
public class FastPlaceClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("ObsidianCrystalOptimizer");

    @Override
    public void onInitializeClient() {
        LOGGER.info("[ObsidianCrystalOptimizer] loaded (enabled = {})", OptimizerState.enabled);
    }
}
