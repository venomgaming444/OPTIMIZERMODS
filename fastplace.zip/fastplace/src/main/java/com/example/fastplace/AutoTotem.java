package com.example.fastplace;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Keeps a Totem of Undying ready, with no delay, after every pop.
 *
 *  - Offhand: if the offhand is not a totem, a totem is swapped in from the
 *    inventory (or the hotbar) in the same tick the empty offhand is seen.
 *  - Hotbar: if a hotbar slot that held a totem becomes empty (it popped),
 *    it is refilled from the inventory.
 *
 * It sends the same slot-click packets as opening the inventory and clicking,
 * but does not show the inventory screen. A visible screen would release
 * right-click and movement and unlock the mouse, which would stop crystal
 * spamming and move the crosshair.
 *
 * Slot numbers in the player screen handler: 9-35 inventory, 36-44 hotbar,
 * 45 offhand. SWAP with button 40 swaps with the offhand; button 0-8 swaps
 * with that hotbar slot.
 */
public final class AutoTotem {
    private static final int OFFHAND_BUTTON = 40;

    private static long tickCounter = 0;
    private static long lastOffhandSwap = -10;
    private static final boolean[] HOTBAR_HAD_TOTEM = new boolean[9];

    private AutoTotem() {}

    public static void tick(MinecraftClient client) {
        if (!OptimizerState.enabled || !OptimizerState.autoTotem) return;

        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null) return;

        // Only act with no screen, or with the player's own inventory open.
        Screen screen = client.currentScreen;
        if (screen != null && !(screen instanceof InventoryScreen)) return;

        ScreenHandler handler = player.playerScreenHandler;
        if (handler.slots.size() < 46) return;
        int sync = handler.syncId;
        tickCounter++;

        // 1) Offhand always gets a totem. Inventory first, then hotbar.
        if (!player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING) && tickCounter - lastOffhandSwap >= 2) {
            int src = findTotem(handler, 9, 44);
            if (src != -1) {
                client.interactionManager.clickSlot(sync, src, OFFHAND_BUTTON, SlotActionType.SWAP, player);
                lastOffhandSwap = tickCounter;
            }
        }

        // 2) A hotbar totem that popped leaves an empty slot: refill it.
        for (int i = 0; i < 9; i++) {
            ItemStack stack = handler.getSlot(36 + i).getStack();
            boolean has = stack.isOf(Items.TOTEM_OF_UNDYING);
            if (!has && HOTBAR_HAD_TOTEM[i] && stack.isEmpty()) {
                int src = findTotem(handler, 9, 35);
                if (src != -1) {
                    client.interactionManager.clickSlot(sync, src, i, SlotActionType.SWAP, player);
                    has = true; // the click is applied on the client right away
                }
            }
            HOTBAR_HAD_TOTEM[i] = has;
        }
    }

    private static int findTotem(ScreenHandler handler, int from, int to) {
        for (int i = from; i <= to; i++) {
            if (handler.getSlot(i).getStack().isOf(Items.TOTEM_OF_UNDYING)) return i;
        }
        return -1;
    }
}
