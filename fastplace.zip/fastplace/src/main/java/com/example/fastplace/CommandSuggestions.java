package com.example.fastplace;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.suggestion.SuggestionProvider;

/**
 * Adds /ObsidianCrystalOptimizer to the client's command tree so the chat box
 * stops showing it in red and offers clickable suggestions (Enable, Disable,
 * Delay, Crystals, Totem, and the numbers). The commands themselves are still
 * run by ClientPlayNetworkHandlerMixin, so nothing is sent to the server.
 *
 * Raw types are used on purpose: the dispatcher's generic type is different
 * between Minecraft versions, and raw types compile against all of them.
 */
@SuppressWarnings({"rawtypes", "unchecked"})
public final class CommandSuggestions {
    private static final String ROOT = "ObsidianCrystalOptimizer";

    private CommandSuggestions() {}

    public static void register(CommandDispatcher dispatcher) {
        if (dispatcher == null) return;

        LiteralArgumentBuilder root = LiteralArgumentBuilder.literal(ROOT).executes(c -> 0);
        root.then(leaf("Enable"));
        root.then(leaf("Disable"));
        root.then(number("Delay", 1, 4));
        root.then(number("Crystals", 0, 10));
        root.then(LiteralArgumentBuilder.literal("Totem")
                .executes(c -> 0)
                .then(leaf("Enable"))
                .then(leaf("Disable")));

        dispatcher.register(root);
    }

    private static LiteralArgumentBuilder leaf(String name) {
        return LiteralArgumentBuilder.literal(name).executes(c -> 0);
    }

    private static LiteralArgumentBuilder number(String name, int min, int max) {
        SuggestionProvider suggest = (ctx, builder) -> {
            for (int i = min; i <= max; i++) {
                builder.suggest(String.valueOf(i));
            }
            return builder.buildFuture();
        };
        RequiredArgumentBuilder arg = RequiredArgumentBuilder
                .argument("value", IntegerArgumentType.integer(min, max))
                .suggests(suggest)
                .executes(c -> 0);
        return LiteralArgumentBuilder.literal(name).executes(c -> 0).then(arg);
    }
}
