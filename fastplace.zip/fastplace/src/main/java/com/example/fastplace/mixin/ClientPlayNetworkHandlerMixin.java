package com.example.fastplace.mixin;

import com.example.fastplace.OptimizerState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Handles these client-side commands (they never reach the server):
 *   /ObsidianCrystalOptimizer Enable
 *   /ObsidianCrystalOptimizer Disable
 *   /ObsidianCrystalOptimizer Delay <1-4>      place speed (1 = fastest, 4 = vanilla)
 *   /ObsidianCrystalOptimizer Crystals <0-10>  crystals broken per tick (0 = off)
 * Done with a mixin so the mod keeps working without Fabric API installed.
 */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "sendChatCommand", at = @At("HEAD"), cancellable = true)
    private void fastplace$command(String command, CallbackInfo ci) {
        String[] parts = command.trim().split("\\s+");
        if (parts.length == 0 || !parts[0].equalsIgnoreCase("ObsidianCrystalOptimizer")) return;

        ci.cancel(); // keep it local, never send to the server

        String reply;
        Formatting color = Formatting.GREEN;
        String sub = parts.length >= 2 ? parts[1].toLowerCase() : "";
        int value = parts.length >= 3 ? fastplace$parse(parts[2]) : -1;

        if (sub.equals("enable")) {
            OptimizerState.enabled = true;
            reply = "ObsidianCrystalOptimizer enabled. " + fastplace$status();
        } else if (sub.equals("disable")) {
            OptimizerState.enabled = false;
            reply = "ObsidianCrystalOptimizer disabled";
            color = Formatting.RED;
        } else if (sub.equals("delay")) {
            if (value >= 1 && value <= 4) {
                OptimizerState.interval = value;
                reply = "Place delay set to " + value + " tick(s) (1 = fastest, 4 = vanilla)";
            } else {
                reply = "Usage: /ObsidianCrystalOptimizer Delay <1-4>. " + fastplace$status();
                color = Formatting.YELLOW;
            }
        } else if (sub.equals("crystals")) {
            if (value >= 0 && value <= 10) {
                OptimizerState.breakCount = value;
                reply = value == 0
                        ? "Auto-break off"
                        : "Auto-break set to " + value + " crystal(s) per tick";
            } else {
                reply = "Usage: /ObsidianCrystalOptimizer Crystals <0-10>. " + fastplace$status();
                color = Formatting.YELLOW;
            }
        } else {
            reply = "Usage: /ObsidianCrystalOptimizer Enable | Disable | Delay <1-4> | Crystals <0-10>. "
                    + fastplace$status();
            color = Formatting.YELLOW;
        }

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal(reply).formatted(color), false);
        }
    }

    private static int fastplace$parse(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static String fastplace$status() {
        return "(" + (OptimizerState.enabled ? "enabled" : "disabled")
                + ", delay " + OptimizerState.interval
                + ", crystals " + OptimizerState.breakCount + ")";
    }
}
