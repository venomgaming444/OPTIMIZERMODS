package com.example.fastplace.mixin;

import com.example.fastplace.OptimizerState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Handles /ObsidianCrystalOptimizer Enable|Disable on the client, so the
 * command never reaches the server. Done with a mixin instead of Fabric API's
 * client command API so the mod keeps working without Fabric API installed.
 */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "sendChatCommand", at = @At("HEAD"), cancellable = true)
    private void fastplace$command(String command, CallbackInfo ci) {
        String[] parts = command.trim().split("\\s+");
        if (parts.length == 0 || !parts[0].equalsIgnoreCase("ObsidianCrystalOptimizer")) return;

        ci.cancel(); // keep it local, never send to the server

        String reply;
        Formatting color;
        if (parts.length >= 2 && parts[1].equalsIgnoreCase("enable")) {
            OptimizerState.enabled = true;
            reply = "ObsidianCrystalOptimizer enabled";
            color = Formatting.GREEN;
        } else if (parts.length >= 2 && parts[1].equalsIgnoreCase("disable")) {
            OptimizerState.enabled = false;
            reply = "ObsidianCrystalOptimizer disabled";
            color = Formatting.RED;
        } else {
            reply = "Usage: /ObsidianCrystalOptimizer Enable|Disable (currently "
                    + (OptimizerState.enabled ? "enabled" : "disabled") + ")";
            color = Formatting.YELLOW;
        }

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) {
            mc.player.sendMessage(Text.literal(reply).formatted(color), false);
        }
    }
}
