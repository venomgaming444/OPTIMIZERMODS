package com.example.fastplace;

/** Shared settings for the Obsidian/End Crystal optimizer. */
public final class OptimizerState {
    /** Enabled by default; toggled with /ObsidianCrystalOptimizer Enable|Disable. */
    public static volatile boolean enabled = true;

    /**
     * Ticks between placements while holding right-click.
     * 1 = fastest (every tick), 4 = vanilla speed.
     * Change with /ObsidianCrystalOptimizer Delay <1-4>.
     */
    public static volatile int interval = 2;

    /**
     * How many End Crystals in reach are broken per tick while right-click is
     * held with a crystal in hand. 0 = auto-break off, max 10.
     * Change with /ObsidianCrystalOptimizer Crystals <0-10>.
     */
    public static volatile int breakCount = 3;

    private OptimizerState() {}
}
