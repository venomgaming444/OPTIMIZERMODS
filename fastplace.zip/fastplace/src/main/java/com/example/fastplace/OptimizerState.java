package com.example.fastplace;

/** Shared on/off switch for the Obsidian/End Crystal optimizer. */
public final class OptimizerState {
    /** Enabled by default; toggled with /ObsidianCrystalOptimizer Enable|Disable. */
    public static volatile boolean enabled = true;

    private OptimizerState() {}
}
