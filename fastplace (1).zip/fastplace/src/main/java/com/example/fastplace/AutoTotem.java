package com.example.fastplace;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Auto Inventory Totem.
 *
 * When the offhand is not a totem (for example right after a pop):
 *   1. If a hotbar totem slot is set (Totem Slot 1-9) and it holds a totem,
 *      that slot is selected first, so a totem is in your hand at once.
 *   2. The offhand is refilled from the inventory (then the hotbar).
 *   3. You stay on the totem slot, so you can switch to your sword yourself.
 *      If Totem Back is enabled, two ticks later your previous slot is selected again.
 * The hotbar totem slot itself is refilled from the inventory whenever it does
 * not hold a totem. With no totem slot set, a hotbar slot that held a totem and
 * became empty is refilled instead.
 *
 * Totem Open (default on): whenever an inventory is open, even one you opened
 * yourself, the hotbar totem slot gets selected. After a pop that slot is also
 * held for 3 ticks, so another mod or a server correction cannot switch you off it.
 *
 * Totem Delay (0-3) is how many ticks to wait after the pop before moving the
 * totem; 0 acts in the same tick the empty offhand is seen.
 *
 * Totem Delay 0: silent and fastest. Only the click packets are sent, no
 * inventory screen is shown, so right-click and movement are not interrupted.
 * Totem Delay 1-3 (with Totem Screen on, the default): the inventory screen
 * really opens after that many ticks, the totems are taken in that same tick,
 * and the screen closes one tick later. A visible screen releases right-click
 * and movement for those ticks and unlocks the mouse.
 *
 * Slot numbers in the player screen handler: 9-35 inventory, 36-44 hotbar,
 * 45 offhand. SWAP with button 40 swaps with the offhand; button 0-8 swaps
 * with that hotbar slot.
 */
public final class AutoTotem {
    private static final int OFFHAND_BUTTON = 40;

    private static long tickCounter = 0;
    private static long missingSince = -1;
    private static long lastOffhandSwap = -10;
    private static long lastHotbarFill = -10;

    private static int restoreSlot = -1;
    private static long restoreAfter = 0;

    // After a pop, keep the hotbar totem slot selected until this tick (Totem Back off).
    private static long holdUntil = -1;

    private static final boolean[] HOTBAR_HAD_TOTEM = new boolean[9];

    // Totem Screen mode: true while an inventory screen opened by this mod is showing.
    private static boolean openedByMod = false;
    private static long closeAt = 0;

    private AutoTotem() {}

    public static void tick(MinecraftClient client) {
        if (!OptimizerState.enabled || !OptimizerState.autoTotem) return;

        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null) return;

        // Only act with no screen, or with the player's own inventory open.
        Screen screen = client.currentScreen;
        if (screen != null && !(screen instanceof InventoryScreen)) {
            openedByMod = false; // something else took over the screen
            return;
        }

        ScreenHandler handler = player.playerScreenHandler;
        if (handler.slots.size() < 46) return;
        int sync = handler.syncId;
        tickCounter++;

        // Totem Screen mode: close the inventory we opened, one tick after the last click.
        if (openedByMod) {
            if (screen instanceof InventoryScreen) {
                if (tickCounter >= closeAt) {
                    player.closeHandledScreen();
                    openedByMod = false;
                }
            } else {
                openedByMod = false;
            }
        }

        // Totem Open: whenever an inventory is open, select the hotbar totem slot.
        // After a pop the slot is also held for a few ticks, so nothing else can
        // quietly switch you away from it (skipped while Totem Back is in use).
        int totemIdx = OptimizerState.totemSlot - 1;
        if (totemIdx >= 0 && totemIdx <= 8 && restoreSlot < 0) {
            boolean inventoryOpen = screen instanceof InventoryScreen && OptimizerState.totemOpenSwitch;
            boolean holding = !OptimizerState.totemBack && tickCounter <= holdUntil;
            if ((inventoryOpen || holding)
                    && handler.getSlot(36 + totemIdx).getStack().isOf(Items.TOTEM_OF_UNDYING)
                    && player.getInventory().selectedSlot != totemIdx) {
                selectSlot(player, totemIdx);
            }
        }

        boolean offhandOk = player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING);
        if (offhandOk) {
            missingSince = -1;
        } else if (missingSince < 0) {
            missingSince = tickCounter;
        }

        // 1) + 2) Offhand needs a totem: switch to the hotbar totem slot, then refill the offhand.
        if (!offhandOk
                && tickCounter - missingSince >= OptimizerState.totemDelay
                && tickCounter - lastOffhandSwap >= 2) {
            int src = findTotem(handler, 9, 44); // inventory first, then hotbar
            if (src != -1) {
                switchToTotemSlot(player, handler, src);
                showInventory(client, player);
                client.interactionManager.clickSlot(sync, src, OFFHAND_BUTTON, SlotActionType.SWAP, player);
                lastOffhandSwap = tickCounter;
            }
        }

        // 3) Only with Totem Back enabled: go back to the slot you were on,
        //    once the offhand has its totem again. (restoreSlot is only set in that case.)
        if (restoreSlot >= 0 && tickCounter >= restoreAfter) {
            if (player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                int totemIndex = OptimizerState.totemSlot - 1;
                PlayerInventory inv = player.getInventory();
                if (totemIndex >= 0 && inv.selectedSlot == totemIndex) {
                    selectSlot(player, restoreSlot);
                }
                restoreSlot = -1;
            } else if (tickCounter > restoreAfter + 40) {
                restoreSlot = -1; // gave up waiting
            }
        }

        // Keep the hotbar totem slot stocked.
        int totemSlot = OptimizerState.totemSlot;
        if (totemSlot >= 1 && totemSlot <= 9) {
            int idx = totemSlot - 1;
            if (!handler.getSlot(36 + idx).getStack().isOf(Items.TOTEM_OF_UNDYING)
                    && tickCounter - lastHotbarFill >= 2) {
                int src = findTotem(handler, 9, 35);
                if (src != -1) {
                    showInventory(client, player);
                    client.interactionManager.clickSlot(sync, src, idx, SlotActionType.SWAP, player);
                    lastHotbarFill = tickCounter;
                }
            }
        } else {
            // No totem slot set: refill a hotbar slot that held a totem and became empty.
            for (int i = 0; i < 9; i++) {
                ItemStack stack = handler.getSlot(36 + i).getStack();
                boolean has = stack.isOf(Items.TOTEM_OF_UNDYING);
                if (!has && HOTBAR_HAD_TOTEM[i] && stack.isEmpty()) {
                    int src = findTotem(handler, 9, 35);
                    if (src != -1) {
                        showInventory(client, player);
                        client.interactionManager.clickSlot(sync, src, i, SlotActionType.SWAP, player);
                        has = true; // the click is applied on the client right away
                    }
                }
                HOTBAR_HAD_TOTEM[i] = has;
            }
        }
    }

    /** Selects the hotbar totem slot first, if one is set and holds a totem. */
    private static void switchToTotemSlot(ClientPlayerEntity player, ScreenHandler handler, int offhandSource) {
        int totemSlot = OptimizerState.totemSlot;
        if (totemSlot < 1 || totemSlot > 9) return;

        int idx = totemSlot - 1;
        // If the offhand totem is about to come from this very slot, there is nothing to hold.
        if (offhandSource == 36 + idx) return;
        if (!handler.getSlot(36 + idx).getStack().isOf(Items.TOTEM_OF_UNDYING)) return;

        holdUntil = tickCounter + 3; // keep this slot selected for a few ticks after the pop

        PlayerInventory inv = player.getInventory();
        if (inv.selectedSlot == idx) return;

        if (OptimizerState.totemBack) {
            restoreSlot = inv.selectedSlot;
            restoreAfter = tickCounter + 2;
        }
        selectSlot(player, idx);
    }

    /**
     * Totem Screen mode: really opens the inventory screen right before the
     * clicks (same tick, so 0 ticks between opening and taking the totems) and
     * schedules it to close one tick later. Does nothing when the mode is off or
     * an inventory is already open.
     */
    private static void showInventory(MinecraftClient client, ClientPlayerEntity player) {
        // Totem Delay 0 = silent and fastest (no screen). Delay 1-3 = the screen shows.
        if (!OptimizerState.totemScreen || OptimizerState.totemDelay < 1) return;
        if (client.currentScreen == null) {
            client.setScreen(new InventoryScreen(player));
            openedByMod = true;
        }
        if (openedByMod) {
            closeAt = tickCounter + 1;
        }
    }

    /** Changes the selected hotbar slot and tells the server right away. */
    private static void selectSlot(ClientPlayerEntity player, int idx) {
        player.getInventory().selectedSlot = idx;
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(idx));
    }

    private static int findTotem(ScreenHandler handler, int from, int to) {
        for (int i = from; i <= to; i++) {
            if (handler.getSlot(i).getStack().isOf(Items.TOTEM_OF_UNDYING)) return i;
        }
        return -1;
    }
}
