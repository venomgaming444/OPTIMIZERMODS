package com.example.fastplace;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.suggestion.SuggestionProvider;

/**
 * Adds /ObsidianCrystalOptimizer to the client's command tree so the chat box
 * stops showing it in red and offers clickable suggestions (Enable, Disable,
 * Delay, Crystals, Totem, and the numbers). The commands themselves are still
 * run by ClientPlayNetworkHandlerMixin, so nothing is sent to the server.
 *
 * The dispatcher's generic type differs between Minecraft versions, so this
 * class is generic over the command source type S and works with all of them.
 */
public final class CommandSuggestions {
    private static final String ROOT = "ObsidianCrystalOptimizer";

    private CommandSuggestions() {}

    public static <S> void register(CommandDispatcher<S> dispatcher) {
        if (dispatcher == null) return;

        LiteralArgumentBuilder<S> root = LiteralArgumentBuilder.<S>literal(ROOT).executes(c -> 0);
        root.then(CommandSuggestions.<S>leaf("Enable"));
        root.then(CommandSuggestions.<S>leaf("Disable"));
        root.then(CommandSuggestions.<S>number("Delay", 1, 4));
        root.then(CommandSuggestions.<S>number("Crystals", 0, 10));

        LiteralArgumentBuilder<S> totem = LiteralArgumentBuilder.<S>literal("Totem").executes(c -> 0);
        totem.then(CommandSuggestions.<S>leaf("Enable"));
        totem.then(CommandSuggestions.<S>leaf("Disable"));
        LiteralArgumentBuilder<S> slot = CommandSuggestions.<S>number("Slot", 1, 9);
        slot.then(CommandSuggestions.<S>leaf("Off"));
        totem.then(slot);
        totem.then(CommandSuggestions.<S>number("Delay", 0, 3));
        LiteralArgumentBuilder<S> back = LiteralArgumentBuilder.<S>literal("Back").executes(c -> 0);
        back.then(CommandSuggestions.<S>leaf("Enable"));
        back.then(CommandSuggestions.<S>leaf("Disable"));
        totem.then(back);
        LiteralArgumentBuilder<S> screen = LiteralArgumentBuilder.<S>literal("Screen").executes(c -> 0);
        screen.then(CommandSuggestions.<S>leaf("Enable"));
        screen.then(CommandSuggestions.<S>leaf("Disable"));
        totem.then(screen);
        LiteralArgumentBuilder<S> open = LiteralArgumentBuilder.<S>literal("Open").executes(c -> 0);
        open.then(CommandSuggestions.<S>leaf("Enable"));
        open.then(CommandSuggestions.<S>leaf("Disable"));
        totem.then(open);
        root.then(totem);

        dispatcher.register(root);
    }

    private static <S> LiteralArgumentBuilder<S> leaf(String name) {
        return LiteralArgumentBuilder.<S>literal(name).executes(c -> 0);
    }

    private static <S> LiteralArgumentBuilder<S> number(String name, int min, int max) {
        SuggestionProvider<S> suggest = (ctx, builder) -> {
            for (int i = min; i <= max; i++) {
                builder.suggest(String.valueOf(i));
            }
            return builder.buildFuture();
        };

        RequiredArgumentBuilder<S, Integer> arg = RequiredArgumentBuilder.<S, Integer>argument(
                "value", IntegerArgumentType.integer(min, max));
        arg.suggests(suggest);
        arg.executes(c -> 0);

        LiteralArgumentBuilder<S> literal = LiteralArgumentBuilder.<S>literal(name).executes(c -> 0);
        literal.then(arg);
        return literal;
    }
}
