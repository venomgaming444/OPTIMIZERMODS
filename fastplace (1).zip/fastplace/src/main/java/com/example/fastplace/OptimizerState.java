package com.example.fastplace;

/** Shared settings for the Obsidian/End Crystal optimizer. */
public final class OptimizerState {
    /** Enabled by default; toggled with /ObsidianCrystalOptimizer Enable|Disable. */
    public static volatile boolean enabled = true;

    /**
     * Ticks between placements while holding right-click.
     * 1 = fastest (every tick), 4 = vanilla speed.
     * Change with /ObsidianCrystalOptimizer Delay <1-4>.
     */
    public static volatile int interval = 2;

    /**
     * How many End Crystals in reach are broken per tick while right-click is
     * held with a crystal in hand. 0 = auto-break off, max 10.
     * Change with /ObsidianCrystalOptimizer Crystals <0-10>.
     */
    public static volatile int breakCount = 3;

    /**
     * Auto Inventory Totem: refills the offhand from the inventory right after
     * a pop. Change with /ObsidianCrystalOptimizer Totem Enable|Disable.
     */
    public static volatile boolean autoTotem = true;

    /**
     * Hotbar slot (1-9) that always keeps a totem. On a pop the game first
     * switches to this slot, then refills the offhand (see totemBack below).
     * 0 = off. Change with /ObsidianCrystalOptimizer Totem Slot <1-9|Off>.
     */
    public static volatile int totemSlot = 0;

    /**
     * Ticks to wait after a pop before the totem is moved. 0 = same tick.
     * Change with /ObsidianCrystalOptimizer Totem Delay <0-3>.
     */
    public static volatile int totemDelay = 0;

    /**
     * false (default): after a pop you stay on the totem hotbar slot, so you
     * can switch to your sword yourself. true: two ticks after the refill the
     * game selects your previous hotbar slot again.
     * Change with /ObsidianCrystalOptimizer Totem Back Enable|Disable.
     */
    public static volatile boolean totemBack = false;

    /**
     * true (default): with Totem Delay 1-3, a pop really opens the inventory
     * screen, takes the totems and closes it one tick later. With Totem Delay 0
     * no screen is shown (silent, fastest). false: never show the screen.
     * Change with /ObsidianCrystalOptimizer Totem Screen Enable|Disable.
     */
    public static volatile boolean totemScreen = true;

    /**
     * true (default): whenever an inventory is open, the hotbar totem slot
     * (Totem Slot) is selected automatically.
     * Change with /ObsidianCrystalOptimizer Totem Open Enable|Disable.
     */
    public static volatile boolean totemOpenSwitch = true;

    private OptimizerState() {}
}
