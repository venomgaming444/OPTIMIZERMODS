package com.example.fastplace;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Properties;

/**
 * Saves and loads every setting, so the commands only have to be typed once.
 *
 * File: <instance folder>/config/obsidiancrystaloptimizer.properties
 * It is created with the defaults on the first start, rewritten after every
 * /ObsidianCrystalOptimizer command, and read again when the game starts.
 * It can also be edited by hand while the game is closed. Bad or missing values
 * fall back to the defaults, so a broken file can never stop the game.
 */
public final class ConfigStore {
    private static final String FILE_NAME = "obsidiancrystaloptimizer.properties";

    private ConfigStore() {}

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve(FILE_NAME);
    }

    /** Reads the file into OptimizerState. Creates it with defaults if it does not exist. */
    public static synchronized void load() {
        try {
            Path file = path();
            if (!Files.exists(file)) {
                save();
                return;
            }

            Properties props = new Properties();
            try (InputStream in = Files.newInputStream(file)) {
                props.load(in);
            }

            OptimizerState.enabled = readBool(props, "enabled", OptimizerState.enabled);
            OptimizerState.interval = readInt(props, "delay", OptimizerState.interval, 1, 4);
            OptimizerState.breakCount = readInt(props, "crystals", OptimizerState.breakCount, 0, 10);
            OptimizerState.autoTotem = readBool(props, "totem", OptimizerState.autoTotem);
            OptimizerState.totemSlot = readInt(props, "totemSlot", OptimizerState.totemSlot, 0, 9);
            OptimizerState.totemDelay = readInt(props, "totemDelay", OptimizerState.totemDelay, 0, 3);
            OptimizerState.totemBack = readBool(props, "totemBack", OptimizerState.totemBack);
            OptimizerState.totemScreen = readBool(props, "totemScreen", OptimizerState.totemScreen);
            OptimizerState.totemOpenSwitch = readBool(props, "totemOpen", OptimizerState.totemOpenSwitch);
        } catch (IOException | RuntimeException e) {
            FastPlaceClient.LOGGER.warn("[ObsidianCrystalOptimizer] could not read the settings file, using defaults: {}", e.toString());
        }
    }

    /** Writes every setting to the file. */
    public static synchronized void save() {
        try {
            Path file = path();
            Path dir = file.getParent();
            if (dir != null) {
                Files.createDirectories(dir);
            }

            Properties props = new Properties();
            props.setProperty("enabled", String.valueOf(OptimizerState.enabled));
            props.setProperty("delay", String.valueOf(OptimizerState.interval));
            props.setProperty("crystals", String.valueOf(OptimizerState.breakCount));
            props.setProperty("totem", String.valueOf(OptimizerState.autoTotem));
            props.setProperty("totemSlot", String.valueOf(OptimizerState.totemSlot));
            props.setProperty("totemDelay", String.valueOf(OptimizerState.totemDelay));
            props.setProperty("totemBack", String.valueOf(OptimizerState.totemBack));
            props.setProperty("totemScreen", String.valueOf(OptimizerState.totemScreen));
            props.setProperty("totemOpen", String.valueOf(OptimizerState.totemOpenSwitch));

            // Write to a temporary file first, so a crash never leaves a half-written file.
            Path tmp = file.resolveSibling(FILE_NAME + ".tmp");
            try (OutputStream out = Files.newOutputStream(tmp)) {
                props.store(out, "ObsidianCrystalOptimizer settings (changed by the /ObsidianCrystalOptimizer commands)");
            }
            Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException | RuntimeException e) {
            FastPlaceClient.LOGGER.warn("[ObsidianCrystalOptimizer] could not save the settings file: {}", e.toString());
        }
    }

    private static boolean readBool(Properties props, String key, boolean fallback) {
        String value = props.getProperty(key);
        if (value == null) return fallback;
        value = value.trim();
        if (value.equalsIgnoreCase("true")) return true;
        if (value.equalsIgnoreCase("false")) return false;
        return fallback;
    }

    private static int readInt(Properties props, String key, int fallback, int min, int max) {
        String value = props.getProperty(key);
        if (value == null) return fallback;
        try {
            int parsed = Integer.parseInt(value.trim());
            return Math.max(min, Math.min(max, parsed));
        } catch (NumberFormatException e) {
            return fallback;
        }
    }
}
