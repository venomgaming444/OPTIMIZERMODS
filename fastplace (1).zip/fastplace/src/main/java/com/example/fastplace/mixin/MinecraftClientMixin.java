package com.example.fastplace.mixin;

import com.example.fastplace.AutoTotem;
import com.example.fastplace.CrystalBreaker;
import com.example.fastplace.OptimizerState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Vanilla sets itemUseCooldown = 4 after each use and only lets a held
 * right-click use an item again when it reaches 0. At the start of every
 * client tick we cap it to the chosen interval (1 = every tick, 4 = vanilla),
 * only while the optimizer is enabled and Obsidian or an End Crystal is in
 * either hand. Then the crystal auto-breaker and the auto totem run for the
 * same tick.
 */
@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {
    @Shadow public ClientPlayerEntity player;
    @Shadow private int itemUseCooldown;

    @Inject(method = "tick", at = @At("HEAD"))
    private void fastplace$tick(CallbackInfo ci) {
        if (!OptimizerState.enabled || player == null) return;

        if (fastplace$isTarget(player.getMainHandStack().getItem())
                || fastplace$isTarget(player.getOffHandStack().getItem())) {
            int cap = OptimizerState.interval;
            if (itemUseCooldown > cap) {
                itemUseCooldown = cap;
            }
        }

        MinecraftClient client = (MinecraftClient) (Object) this;
        CrystalBreaker.tick(client);
        AutoTotem.tick(client);
    }

    private static boolean fastplace$isTarget(Item item) {
        return item == Items.OBSIDIAN || item == Items.END_CRYSTAL;
    }
}
