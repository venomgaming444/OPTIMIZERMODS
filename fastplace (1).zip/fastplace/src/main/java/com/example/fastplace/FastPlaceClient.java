package com.example.fastplace;

import net.fabricmc.api.ClientModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Client entrypoint. Loads the saved settings and writes a "loaded" line to
 * latest.log, so you can check that the mod started.
 * ClientModInitializer ships with Fabric Loader, so Fabric API is not needed.
 */
public class FastPlaceClient implements ClientModInitializer {
    public static final Logger LOGGER = LoggerFactory.getLogger("ObsidianCrystalOptimizer");

    @Override
    public void onInitializeClient() {
        ConfigStore.load();
        LOGGER.info("[ObsidianCrystalOptimizer] loaded (enabled = {}, delay = {}, crystals = {}, totem = {}, totem slot = {})",
                OptimizerState.enabled, OptimizerState.interval, OptimizerState.breakCount,
                OptimizerState.autoTotem, OptimizerState.totemSlot);
    }
}
