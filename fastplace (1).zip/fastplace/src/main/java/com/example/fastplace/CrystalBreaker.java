package com.example.fastplace;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * While right-click is held with an End Crystal in hand, hits End Crystals that
 * are inside normal reach, nearest first, up to OptimizerState.breakCount per tick.
 *
 * A crystal that was just hit stays on the client until the server confirms, so
 * each crystal is left alone for a few ticks (scaled to your ping) before it is
 * hit again. That avoids spamming the server and keeps hits from being dropped.
 */
public final class CrystalBreaker {
    private static final Map<Integer, Long> LAST_HIT = new HashMap<>();
    private static long tickCounter = 0;

    private CrystalBreaker() {}

    public static void tick(MinecraftClient client) {
        if (!OptimizerState.enabled || OptimizerState.breakCount <= 0) return;

        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null) return;
        if (client.currentScreen != null) return;
        if (!client.options.useKey.isPressed()) return;
        if (!player.getMainHandStack().isOf(Items.END_CRYSTAL)
                && !player.getOffHandStack().isOf(Items.END_CRYSTAL)) return;

        tickCounter++;
        LAST_HIT.values().removeIf(t -> tickCounter - t > 60);

        double reach = player.isCreative() ? 5.0 : 3.0;
        double reachSq = reach * reach;
        Vec3d eye = player.getEyePos();
        long wait = waitTicks(client, player);

        List<EndCrystalEntity> inReach = new ArrayList<>();
        for (EndCrystalEntity crystal : client.world.getEntitiesByClass(
                EndCrystalEntity.class, player.getBoundingBox().expand(reach + 2.0), e -> !e.isRemoved())) {
            if (distanceSq(eye, crystal.getBoundingBox()) <= reachSq) {
                inReach.add(crystal);
            }
        }
        if (inReach.isEmpty()) return;

        inReach.sort((a, b) -> Double.compare(
                distanceSq(eye, a.getBoundingBox()), distanceSq(eye, b.getBoundingBox())));

        int hits = 0;
        for (EndCrystalEntity crystal : inReach) {
            if (hits >= OptimizerState.breakCount) break;
            Long last = LAST_HIT.get(crystal.getId());
            if (last != null && tickCounter - last < wait) continue;

            client.interactionManager.attackEntity(player, crystal);
            player.swingHand(Hand.MAIN_HAND);
            LAST_HIT.put(crystal.getId(), tickCounter);
            hits++;
        }
    }

    /** Squared distance from the eye to the closest point of the box. */
    private static double distanceSq(Vec3d eye, Box b) {
        double dx = Math.max(Math.max(b.minX - eye.x, 0.0), eye.x - b.maxX);
        double dy = Math.max(Math.max(b.minY - eye.y, 0.0), eye.y - b.maxY);
        double dz = Math.max(Math.max(b.minZ - eye.z, 0.0), eye.z - b.maxZ);
        return dx * dx + dy * dy + dz * dz;
    }

    /** Ticks to wait before hitting the same crystal again (grows with ping). */
    private static long waitTicks(MinecraftClient client, ClientPlayerEntity player) {
        int latency = 0;
        ClientPlayNetworkHandler handler = client.getNetworkHandler();
        if (handler != null) {
            PlayerListEntry entry = handler.getPlayerListEntry(player.getUuid());
            if (entry != null) latency = entry.getLatency();
        }
        long w = (long) Math.ceil(latency / 50.0) + 2;
        return Math.max(3, Math.min(w, 14));
    }
}
